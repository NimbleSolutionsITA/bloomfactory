<?php $__env->startSection('content'); ?>

    <section class="intro_section page_mainslider ds light_md_bg_color all-scr-cover">
        <div class="container">
            <div class="row">
                <div class="col-sm-12" style="text-align: center">
                    <br>
                    <h1 style="color: #333;">Thank You!</h1>
                    <a class="theme_button color1" href="<?php echo e(route('shop')); ?>">Continue Shopping</a>
                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>