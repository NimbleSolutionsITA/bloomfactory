<?php $__env->startSection('content'); ?>
    <section class="intro_section page_mainslider ds light_md_bg_color all-scr-cover">
        <div class="flexslider" data-dots="true" data-nav="true">
            <ul class="slides">
                <li>
                    <div class="slide-image-wrap">
                        <div class="rounded-container"> <img src="/images/slide01.jpg" alt=""> </div>
                    </div>
                    <div class="container">
                        <div class="row">
                            <div class="col-sm-12 text-center">
                                <div class="slide_description_wrapper">
                                    <div class="slide_description">
                                        <div class="intro-layer" data-animation="fadeInUp">
                                            <p class="semibold text-uppercase grey"> Our factory in Colorado is producing </p>
                                        </div>
                                        <div class="intro-layer" data-animation="fadeInUp">
                                            <h2>Recreational &amp; Medical Marijuana...</h2>
                                        </div>
                                        <div class="intro-layer" data-animation="fadeInUp">
                                            <div class="slide_buttons"> <a href="contact.html" class="theme_button color4 min_width_button">Buy now</a> </div>
                                        </div>
                                    </div>
                                    <!-- eof .slide_description -->
                                </div>
                                <!-- eof .slide_description_wrapper -->
                            </div>
                            <!-- eof .col-* -->
                        </div>
                        <!-- eof .row -->
                    </div>
                    <!-- eof .container -->
                </li>
                <li>
                    <div class="slide-image-wrap">
                        <div class="rounded-container"> <img src="/images/slide02.jpg" alt=""> </div>
                    </div>
                    <div class="container">
                        <div class="row">
                            <div class="col-sm-12 text-center">
                                <div class="slide_description_wrapper">
                                    <div class="slide_description">
                                        <div class="intro-layer" data-animation="fadeInUp">
                                            <p class="semibold text-uppercase grey"> Our factory in Colorado is producing </p>
                                        </div>
                                        <div class="intro-layer" data-animation="fadeInUp">
                                            <h2>Recreational &amp; Medical Marijuana...</h2>
                                        </div>
                                        <div class="intro-layer" data-animation="fadeInUp">
                                            <div class="slide_buttons"> <a href="contact.html" class="theme_button color4 min_width_button">Buy now</a> </div>
                                        </div>
                                    </div>
                                    <!-- eof .slide_description -->
                                </div>
                                <!-- eof .slide_description_wrapper -->
                            </div>
                            <!-- eof .col-* -->
                        </div>
                        <!-- eof .row -->
                    </div>
                    <!-- eof .container -->
                </li>
                <li>
                    <div class="slide-image-wrap">
                        <div class="rounded-container"> <img src="/images/slide03.jpg" alt=""> </div>
                    </div>
                    <div class="container">
                        <div class="row">
                            <div class="col-sm-12 text-center">
                                <div class="slide_description_wrapper">
                                    <div class="slide_description">
                                        <div class="intro-layer" data-animation="fadeInUp">
                                            <p class="semibold text-uppercase grey"> Our factory in Colorado is producing </p>
                                        </div>
                                        <div class="intro-layer" data-animation="fadeInUp">
                                            <h2>Recreational &amp; Medical Marijuana...</h2>
                                        </div>
                                        <div class="intro-layer" data-animation="fadeInUp">
                                            <div class="slide_buttons"> <a href="contact.html" class="theme_button color4 min_width_button">Buy now</a> </div>
                                        </div>
                                    </div>
                                    <!-- eof .slide_description -->
                                </div>
                                <!-- eof .slide_description_wrapper -->
                            </div>
                            <!-- eof .col-* -->
                        </div>
                        <!-- eof .row -->
                    </div>
                    <!-- eof .container -->
                </li>
            </ul>
        </div>
        <!-- eof flexslider -->
    </section>
    <section class="ls section_offset_teasers section_padding_top_10 section_padding_bottom_10">
        <div class="container">
            <div class="row">
                <div class="col-md-3 col-sm-6 to_animate no_appear_delay" data-animation="fadeInDown" data-delay="600">
                    <div class="teaser top_offset_icon main_bg_color rounded text-center">
                        <div class="teaser_icon size_small round main_bg_color"> <i class="fa fa-globe" aria-hidden="true"></i> </div>
                        <h4 class="topmargin_0"> <a href="#">Green House</a> </h4>
                        <p class="content-3lines-ellipsis">«Our cannabis is greenhouse grown with love.»</p>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 to_animate no_appear_delay" data-animation="fadeInDown" data-delay="300">
                    <div class="teaser top_offset_icon main_bg_color2 rounded text-center">
                        <div class="teaser_icon size_small round main_bg_color2"> <i class="fa fa-plug" aria-hidden="true"></i> </div>
                        <h4 class="topmargin_0"> <a href="#">Solar Energy</a> </h4>
                        <p class="content-3lines-ellipsis">«What better source of energy than the sun itself.»</p>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 to_animate no_appear_delay" data-animation="fadeInDown" data-delay="300">
                    <div class="teaser top_offset_icon main_bg_color3 rounded text-center">
                        <div class="teaser_icon size_small round main_bg_color3"> <i class="fa fa-leaf" aria-hidden="true"></i> </div>
                        <h4 class="topmargin_0"> <a href="#">Sustainable</a> </h4>
                        <p class="content-3lines-ellipsis">«Low carbon footprint,-Thats why we buy local, reuse.»</p>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 to_animate no_appear_delay" data-animation="fadeInDown" data-delay="600">
                    <div class="teaser top_offset_icon main_bg_color4 rounded text-center">
                        <div class="teaser_icon size_small round main_bg_color4"> <i class="fa fa-users" aria-hidden="true"></i> </div>
                        <h4 class="topmargin_0"> <a href="#">Connoisseurs</a> </h4>
                        <p class="content-3lines-ellipsis">«We are a big family of perfect cannabis connoisseurs.»</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section id="technologies" class="ls section_padding_top_150 section_padding_bottom_150 columns_margin_bottom_40">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-md-4"> <span class="small-text big highlight2">
					Six steps for growing
				</span>
                    <h2 class="section_header">Our Special Technologies</h2>
                    <p class="topmargin_50"> <a href="#" class="theme_button inverse color2 complex_button">
						<span class="left-icon">
							<img src="/images/bbb.png" alt="" draggable="false">
						</span>
                            Accredited<br> bussiness
                            <span class="right-icon">A+</span>
                        </a> </p>
                </div>
                <div class="col-md-8 col-lg-9">
                    <div class="row row-flex">
                        <div class="col-lg-4 col-sm-6">
                            <div class="media bottommargin_25">
                                <div class="media-left media-middle"> <img src="/images/icons/01.png" alt=""> </div>
                                <div class="media-body media-middle">
                                    <h4 class="entry-title hover-color2"> <a href="#">Germinate New Seeds</a> </h4>
                                </div>
                            </div>
                            <p>One of the easiest ways to germinate seed is to place it directly in a specialized starter cube.</p>
                        </div>
                        <div class="col-lg-4 col-sm-6">
                            <div class="media bottommargin_25">
                                <div class="media-left media-middle"> <img src="/images/icons/02.png" alt=""> </div>
                                <div class="media-body media-middle">
                                    <h4 class="entry-title hover-color2"> <a href="#">Start Our Clones Indoors</a> </h4>
                                </div>
                            </div>
                            <p>Just keep starter cubes moist and warm. Seedlings should pop in a few days to a week.</p>
                        </div>
                        <div class="col-lg-4 col-sm-6">
                            <div class="media bottommargin_25">
                                <div class="media-left media-middle"> <img src="/images/icons/03.png" alt=""> </div>
                                <div class="media-body media-middle">
                                    <h4 class="entry-title hover-color2"> <a href="#">Vegetative - Stems and Leaves</a> </h4>
                                </div>
                            </div>
                            <p>In this stage, our plant will focus only on cannabis getting big and strong, like a kid.</p>
                        </div>
                        <div class="col-lg-4 col-sm-6">
                            <div class="media bottommargin_25">
                                <div class="media-left media-middle"> <img src="/images/icons/04.png" alt=""> </div>
                                <div class="media-body media-middle">
                                    <h4 class="entry-title hover-color2"> <a href="#">Flowering - Buds Start Growing!</a> </h4>
                                </div>
                            </div>
                            <p>Our cannabis goes through "puberty" and basically reveals whether they are a boy or a girl.</p>
                        </div>
                        <div class="col-lg-4 col-sm-6">
                            <div class="media bottommargin_25">
                                <div class="media-left media-middle"> <img src="/images/icons/05.png" alt=""> </div>
                                <div class="media-body media-middle">
                                    <h4 class="entry-title hover-color2"> <a href="#">Getting Friendly Nutrients</a> </h4>
                                </div>
                            </div>
                            <p>It's important to pay close attention to your cannabis plants during the Flowering stage.</p>
                        </div>
                        <div class="col-lg-4 col-sm-6">
                            <div class="media bottommargin_25">
                                <div class="media-left media-middle"> <img src="/images/icons/06.png" alt=""> </div>
                                <div class="media-body media-middle">
                                    <h4 class="entry-title hover-color2"> <a href="#">Harvest Our Cannabis</a> </h4>
                                </div>
                            </div>
                            <p>The hardest part of growing cannabis for many grower's is waiting for the right time to harvest.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section id="products" class="ds parallax page_shop section_padding_top_150 section_padding_bottom_150">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-sm-4"> <span class="small-text big highlight4">
					Our Shop
				</span>
                    <h2 class="section_header">Buy Cannabis Here</h2>
                    <div class="widget widget_categories topmargin_50">
                        <ul class="greylinks color4">
                            <li class=""> <a href="blog-left.html">Cannabis</a> </li>
                            <li class=""> <a href="blog-left.html">Concentrates</a> </li>
                            <li class=""> <a href="blog-left.html">Flowers</a> </li>
                            <li class=""> <a href="blog-left.html">Pre-Rolls</a> </li>
                        </ul>
                    </div>
                    <p class="topmargin_40"> <a href="shop-left.html" class="theme_button color4">
                            Go to shop
                        </a> </p>
                </div>
                <div class="col-lg-9 col-sm-8">
                    <div class="owl-carousel" data-nav="true" data-responsive-lg="3">
                        <article class="product ls vertical-item content-padding rounded overflow_hidden loop-color">
                            <div class="item-media"> <img src="/images/shop/01.jpg" alt="" /> <span class="price main_bg_color">
								<ins>
									<span class="amount">$50.00</span> </ins>
										</span>
                                <div class="product-buttons"> <a href="#" class="favorite_button">
                                        <span class="sr-only">Add to favorite</span>
                                    </a> <a href="#" class="add_to_cart">
                                        <span class="sr-only">Add to favorite</span>
                                    </a> </div>
                            </div>
                            <div class="item-content">
                                <div class="star-rating" title="Rated 5.0 out of 5"> <span style="width:100%">
									<strong class="rating">5.0</strong> out of 5
								</span> </div>
                                <h4 class="entry-title topmargin_5"> <a href="shop-product-right.html">Cannabis Flowers</a> </h4>
                                <p class="content-3lines-ellipsis">Swine meatball shankle cow kielbasa burgdoggen shoulder andouille pork loin brisket leberkas.</p>
                            </div>
                        </article>
                        <article class="product ls vertical-item content-padding rounded overflow_hidden loop-color">
                            <div class="item-media"> <img src="/images/shop/02.jpg" alt="" /> <span class="price main_bg_color">
								<ins>
									<span class="amount">$85.00</span> </ins>
										</span>
                                <div class="product-buttons"> <a href="#" class="favorite_button">
                                        <span class="sr-only">Add to favorite</span>
                                    </a> <a href="#" class="add_to_cart">
                                        <span class="sr-only">Add to favorite</span>
                                    </a> </div>
                            </div>
                            <div class="item-content">
                                <div class="star-rating" title="Rated 4.0 out of 5"> <span style="width:80%">
									<strong class="rating">4.0</strong> out of 5
								</span> </div>
                                <h4 class="entry-title topmargin_5"> <a href="shop-product-right.html">Cannabis Pre-Rolls</a> </h4>
                                <p class="content-3lines-ellipsis">Pork andouille pig, beef ribs prosciutto sausage picanha leberkas ham hock cow. Kevin doner filet mignon.</p>
                            </div>
                        </article>
                        <article class="product ls vertical-item content-padding rounded overflow_hidden loop-color">
                            <div class="item-media"> <img src="/images/shop/03.jpg" alt="" /> <span class="price main_bg_color">
								<ins>
									<span class="amount">$99.00</span> </ins>
										</span>
                                <div class="product-buttons"> <a href="#" class="favorite_button">
                                        <span class="sr-only">Add to favorite</span>
                                    </a> <a href="#" class="add_to_cart">
                                        <span class="sr-only">Add to favorite</span>
                                    </a> </div>
                            </div>
                            <div class="item-content">
                                <div class="star-rating" title="Rated 3.0 out of 5"> <span style="width:60%">
									<strong class="rating">3.0</strong> out of 5
								</span> </div>
                                <h4 class="entry-title topmargin_5"> <a href="shop-product-right.html">Concentrates</a> </h4>
                                <p class="content-3lines-ellipsis">Biltong ribeye cupim meatloaf, burgd shoulder jerky pork loin turducken alcatra venison sirloin.</p>
                            </div>
                        </article>
                        <article class="product ls vertical-item content-padding rounded overflow_hidden loop-color">
                            <div class="item-media"> <img src="/images/shop/04.jpg" alt="" /> <span class="price main_bg_color">
								<ins>
									<span class="amount">$99.00</span> </ins>
										</span>
                                <div class="product-buttons"> <a href="#" class="favorite_button">
                                        <span class="sr-only">Add to favorite</span>
                                    </a> <a href="#" class="add_to_cart">
                                        <span class="sr-only">Add to favorite</span>
                                    </a> </div>
                            </div>
                            <div class="item-content">
                                <div class="star-rating" title="Rated 3.5 out of 5"> <span style="width:70%">
									<strong class="rating">3.5</strong> out of 5
								</span> </div>
                                <h4 class="entry-title topmargin_5"> <a href="shop-product-right.html">Cannabis Oil</a> </h4>
                                <p class="content-3lines-ellipsis">Pancetta t-bone ball tip pig buffalo, fatback filet mignon brisket frankfurter boudin jowl tenderloin.</p>
                            </div>
                        </article>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="ls page_map" data-address="29-32 Portland Pl South Yarra VIC 3141 Australia">
        <!-- marker description and marker icon goes here -->
        <div class="map_marker_description">
            <h3>Map Title</h3>
            <p>Map description text</p> <img src="/images/map_marker_icon.png" alt="" class="map_marker_icon"> </div>
    </section>
    <section id="subscribe" class="cs main_color2 background_cover overlay_color page_subscribe section_padding_top_75 section_padding_bottom_75 table_section table_section_lg">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-lg-3 text-center text-md-left"> <span class="small-text big black">
					Subscribe now to
				</span>
                    <h2 class="section_header">Our Newsletter</h2>
                </div>
                <div class="col-xs-12 col-sm-6 col-sm-offset-3 col-md-12 col-md-offset-0 col-lg-9">
                    <div class="widget widget_mailchimp">
                        <form class="signup" action="./" method="get">
                            <div class="row">
                                <div class="col-xs-12 col-md-4">
                                    <div class="form-group margin_0"> <input class="form-control mailchimp_fullname" name="fullname" required="" type="text" placeholder="Your Full Name*"> </div>
                                </div>
                                <div class="col-xs-12 col-md-4">
                                    <div class="form-group margin_0"> <input class="mailchimp_email form-control" name="email" required="" type="email" placeholder="Your Email Address*"> </div>
                                </div>
                                <div class="col-xs-12 col-md-4"> <button type="submit" class="theme_button color2 block_button margin_0">Subscribe to newsletter</button> </div>
                                <div class="col-sm-12 margin_0">
                                    <div class="response"></div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>