<div class="js-cookie-consent cookie-consent">

    <div class="message-box">

        <img src="/images/logo-1color-white.png" alt="">

        <span class="cookie-consent__message">
            <?php echo trans('cookieConsent::texts.message'); ?>

        </span>

        <br>

        <a href="<?php echo e(route('cookie-policy')); ?>"><i>Visualizza l'informativa sui cookies</i></a>

        <br>

        <h6 style="text-transform: uppercase;"><?php echo trans('cookieConsent::texts.age'); ?> <input type="checkbox"  onchange="document.getElementById('consent').disabled = !this.checked;" /></h6>

        <br>

        <button class="js-cookie-consent-agree cookie-consent__agree" id="consent" disabled>
            <?php echo e(trans('cookieConsent::texts.agree')); ?>

        </button>

    </div>

</div>