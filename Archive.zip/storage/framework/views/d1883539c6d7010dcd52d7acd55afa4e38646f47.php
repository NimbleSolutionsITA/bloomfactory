<section class="page_breadcrumbs ds parallax section_padding_top_40 section_padding_bottom_40">
    <div class="container">
        <div class="row">
            <div class="col-sm-12 text-center">
                <h2>Products</h2>
                <ol class="breadcrumb greylinks color4">
                    <li> <a href="./">
                            Home
                        </a> </li>
                    <li> <a href="#">Shop</a> </li>
                    <li class="active">Products</li>
                </ol>
            </div>
        </div>
    </div>
</section>