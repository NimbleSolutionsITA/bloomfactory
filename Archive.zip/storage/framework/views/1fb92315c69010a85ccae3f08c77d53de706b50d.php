<?php $__env->startSection('title', 'Carrello'); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('partials.breadcrumbs', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <section class="ls section_padding_top_100 section_padding_bottom_75 columns_padding_25">
        <div class="container">

            <?php if(session()->has('success_message')): ?>
                <div class="alert alert-success alert-dismissible">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                    <strong>Success!</strong> <?php echo e(session()->get('success_message')); ?>

                </div>
            <?php endif; ?>
            <?php if(count($errors) > 0): ?>
                <div class="alert alert-danger alert-dismissible">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <div class="row">
                <!-- <div class="col-sm-7 col-md-8 col-lg-8 col-sm-push-5 col-md-push-4 col-lg-push-4"> -->
                 <div class="col-sm-12">
                    <div class="table-responsive">
                        <table class="table shop_table cart cart-table">
                            <thead>
                            <tr>
                                <td class="product-info">Prodotto</td>
                                <td class="product-price-td">Prezzo</td>
                                <td class="product-quantity">Quantità</td>
                                <td class="product-subtotal">Totale</td>
                                <td class="product-remove">&nbsp;</td>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = Cart::content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <tr class="cart_item">
                                    <td class="product-info">
                                        <div class="media">
                                            <div class="media-left"> <a href="shop-product-right.html">
                                                    <img class="media-object cart-product-image" src="<?php echo e($item->model->image); ?>" alt="">
                                                </a>
                                            </div>
                                            <div class="media-body">
                                                <h4 class="media-heading" style="margin-bottom: 0"> <a href="<?php echo e(route('shop.show', [$item->model->category->slug, $item->model->slug])); ?>"><?php echo e($item->model->name); ?></a> </h4>
                                                <span class="cart-brand"><?php echo e($item->model->brand); ?></span><br>
                                                <?php echo e(\App\Category::where('id', $item->model->category_id)->first()->name); ?>

                                             </div>
                                        </div>
                                    </td>
                                    <td class="product-price"> <span class="currencies">€</span><span class="amount"><?php echo e($item->model->getFormattedPriceAttribute()); ?></span> </td>
                                    <td class="product-quantity">
                                        <form action="<?php echo e(route('cart.update', $item->rowId)); ?>" method="POST">
                                            <?php echo e(csrf_field()); ?>

                                            <select class="quantity" data-id='<?php echo e($item->rowId); ?>'>
                                                <?php for($i = 1; $i < 10 + 1 ; $i++): ?>
                                                    <option <?php echo e($item->qty == $i ? 'selected' : ''); ?>><?php echo e($i); ?></option>
                                                <?php endfor; ?>
                                            </select>
                                        </form>
                                    </td>
                                    <td class="product-subtotal"> <span class="currencies">$</span><span class="amount"><?php echo e(number_format($item->model->getFormattedPriceAttribute() * $item->qty, 2)); ?></span> </td>
                                    <td class="product-remove">
                                        <form action="<?php echo e(route('cart.destroy', $item->rowId)); ?>" method="POST">
                                            <?php echo e(csrf_field()); ?>

                                            <?php echo e(method_field('DELETE')); ?>

                                            <button type="submit" class="remove fontsize_20" title="Remove this item">
                                                <i class="fa fa-trash-o"></i>
                                            </button>
                                        </form>
                                    </td>
                                </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="cart-buttons">
                        <a class="theme_button color1" href="<?php echo e(route('shop')); ?>">Continua lo Shopping</a>
                        <a href="<?php echo e(route('checkout.index')); ?>" class="theme_button inverse">Vai al Checkout</a>
                    </div>
                    <div class="cart-collaterals">
                        <div class="cart_totals">
                            <h4>Totale carrello</h4>
                            <table class="table">
                                <tbody>
                                <tr class="cart-subtotal">
                                    <td>Totele prodotti</td>
                                    <td><span class="currencies">€</span><span class="amount"> <?php echo e(number_format(Cart::subtotal(), 2)); ?></span> </td>
                                </tr>
                                <?php if(Cart::count()>0): ?>
                                    <tr class="shipping">
                                        <td>Spedizione <i>(gratuita per ordini superiori a 75€)</i></td>
                                        <?php if(Cart::subtotal()>75 ): ?>
                                            <td> Spedizione gratuita </td>
                                        <?php else: ?>
                                            <td> € 7.50 </td>
                                        <?php endif; ?>
                                    </tr>
                                <?php endif; ?>
                                <?php if(!empty(Session::get('coupon'))): ?>
                                    <tr class="shipping">
                                        <td>Coupon <?php echo e(Session::get('coupon')['name']); ?>

                                            <form class="coupon_remove" action="<?php echo e(route('coupon.destroy')); ?>" method="POST">
                                                <?php echo e(csrf_field()); ?>

                                                <?php echo e(method_field('delete')); ?>

                                                <button type="submit"><i class="fa fa-trash-o"></i></button>
                                            </form>
                                        </td>
                                        <td>€ <?php echo e(number_format($discount, 2)); ?></td>
                                    </tr>
                                <?php endif; ?>
                                <tr class="order-total">
                                    <td class="grey">Totale ordine</td>
                                    <td><strong class="grey"><span class="currencies">€</span><span class="amount">
                                    <?php if(Cart::subtotal()>75): ?>
                                            <?php echo e(number_format($newSubtotal, 2)); ?>

                                        <?php else: ?>
                                            <?php echo e(number_format($newSubtotal + 7.5, 2)); ?>

                                        <?php endif; ?>
                                    </span> </strong> </td>
                                </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="row">
                        <?php if(empty(Session::get('coupon'))): ?>
                        <div class="col-md-6">
                            <div class="coupon with_padding rounded with_background">
                                <form action="<?php echo e(route('coupon.store')); ?>" method="POST">
                                    <?php echo e(csrf_field()); ?>

                                    <h4 class="topmargin_0">Codici sconto</h4>
                                    <p>Inserisci qui il tuo Coupon se ne possiedi uno</p>
                                    <div class="form-group">
                                        <label class="sr-only" for="coupon_code">Coupon:</label>
                                        <input type="text" name="coupon_code" class="form-control" id="coupon_code" value="" placeholder="Codice sconto">
                                    </div>
                                    <button type="submit" class="theme_button color1" href="#">Applica Coupon</button>
                                </form>
                            </div>
                        </div>
                        <?php endif; ?>
                        <!--
                        <div class="col-md-6">
                            <div class="shipping-calculator-form with_padding rounded with_background">
                                <h4 class="topmargin_0">Shipping &amp; Tax</h4>
                                <p>Enter destination to get shipping</p>
                                <div class="form-group">
                                    <select name="calc_shipping_country" id="calc_shipping_country" class="country_to_state form-control">
                                        <option value="">Select a country…</option>
                                        <option value="AX">Åland Islands</option>
                                        <option value="OM">Oman</option>
                                        <option value="GB" selected="selected">United Kingdom (UK)</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <input type="text" class="form-control" value="" placeholder="State / county" name="calc_shipping_state" id="calc_shipping_state">
                                </div>
                                <div class="form-group">
                                    <input type="text" class="form-control" value="" placeholder="Postcode / Zip" name="calc_shipping_postcode" id="calc_shipping_postcode">
                                </div>
                                <div>
                                    <button type="submit" name="calc_shipping" class="theme_button color1" value="1">Update Totals</button>
                                </div>
                            </div>
                        </div>
                        -->
                    </div>
                </div>
                <!--eof .col-sm-8 (main content)-->
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra-js'); ?>
    <script>
        (function() {
            const classname = document.querySelectorAll('.quantity');

            Array.from(classname).forEach(function(element) {
                element.addEventListener('change', function () {
                    const id = element.getAttribute('data-id');
                    axios.patch(`/cart/${id}`, {
                        quantity: this.value
                    })
                        .then(function (response) {
                            window.location.href = '<?php echo e(route('cart.index')); ?>'
                        })
                        .catch(function (error) {
                            console.log(error);
                            window.location.href = '<?php echo e(route('cart.index')); ?>'
                        });
                });
            })
        })();
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>