<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('partials.breadcrumbs', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <section class="ls section_padding_top_150 section_padding_bottom_100 columns_padding_30">
        <div class="container">
            <div class="row">
                <div class="col-sm-7 col-md-8 col-lg-8 col-sm-push-5 col-md-push-4 col-lg-push-4">
                    <div class="shop-sorting">
                        <form class="form-inline content-justify vertical-center content-margins">
                            <?php if($products->total() == 0): ?>
                                <div>No results to display</div>
                            <?php else: ?>
                                <div> Showing <?php echo e((($products->currentPage() - 1) * $products->perPage()) + 1); ?>-
                                    <?php if($products->currentPage() == $products->lastPage()): ?>
                                        <?php echo e($products->total()); ?>

                                    <?php else: ?>
                                        <?php echo e($products->currentPage() * 4); ?>

                                    <?php endif; ?>
                                    of <?php echo e($products->total()); ?> results
                                </div>
                            <?php endif; ?>
                            <div class="form-group select-group">
                                <select aria-required="true" id="sort" name="sort" class="choice empty form-control" onchange="this.form.submit()">
                                    <option value="" disabled selected data-default>Default Sorting</option>
                                    <option value="pra">by Price asc</option>
                                    <option value="prd">by Price dsc</option>
                                    <option value="naa">by Name asc</option>
                                    <option value="nad">by Name dsc</option>
                                </select>
                                <i class="fa fa-angle-down theme_button color1 no_bg_button" aria-hidden="true"></i>
                            </div>
                        </form>
                    </div>
                    <div class="columns-2">
                        <ul id="products" class="products list-unstyled">

                            <?php $__currentLoopData = $products->getCollection()->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <li class="product type-product loop-color">
                                    <article class="vertical-item content-padding rounded overflow_hidden with_background">
                                        <div class="item-media"> <img src="/images/shop/01.jpg" alt="" /> <span class="price main_bg_color">
                                            <ins>
                                                <span class="amount"><?php echo e($product->price); ?></span> </ins>
                                                    </span>
                                            <div class="product-buttons"> <a href="#" class="favorite_button">
                                                    <span class="sr-only">Add to favorite</span>
                                                </a> <a href="#" class="add_to_cart">
                                                    <span class="sr-only">Add to favorite</span>
                                                </a> </div>
                                        </div>
                                        <div class="item-content">
                                            <div class="star-rating" title="Rated 5.0 out of 5"> <span style="width:100%">
                                                <strong class="rating">5.0</strong> out of 5
                                            </span> </div>
                                            <h4 class="entry-title topmargin_5"> <a href="/shop/<?php echo e($product->slug); ?>"><?php echo e($product->name); ?></a> </h4>
                                            <p class="content-3lines-ellipsis"><?php echo e($product->description); ?></p>
                                        </div>
                                    </article>
                                </li>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        </ul>
                    </div>
                    <!-- eof .columns-* -->
                    <div class="row">
                        <div class="col-sm-12 text-center">
                            <?php echo e($products->links()); ?>

                        </div>
                    </div>
                </div>
                <aside class="col-sm-5 col-md-4 col-lg-4 col-sm-pull-7 col-md-pull-8 col-lg-pull-8">

                    <div class="widget widget_search">
                        <h3 class="widget-title">Search Now</h3>
                        <form method="get" class="form-inline" action="<?php echo e(route('shop')); ?>">
                            <div class="form-group margin_0">
                                <label class="sr-only" for="widget-search">Search for:</label>
                                <input id="widget-search" type="text" value="" name="keyword" class="form-control" placeholder="Type keyword here...">
                            </div>
                            <button type="submit" class="theme_button color4 no_bg_button">Search</button>
                        </form>
                    </div>
                    <div class="widget widget_categories">
                        <h3 class="widget-title">All Categories</h3>
                        <select name="cat" class="wrap-select-group" form="filterform">
                            <option value="0">All</option>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <!--
                    <div class="widget widget_categories">
                        <h3 class="widget-title">Flavor / Smell</h3> <select name="cat" class="wrap-select-group">
                            <option value="1">All</option>
                            <option value="2">Type 1</option>
                            <option value="3">Type 2</option>
                            <option value="4">Type 3</option>
                            <option value="5">Type 4</option>
                        </select>
                    </div>
                    <div class="widget widget_categories">
                        <h3 class="widget-title">Effect</h3> <select name="cat" class="wrap-select-group">
                            <option value="1">All</option>
                            <option value="2">Effect 1</option>
                            <option value="3">Effect 2</option>
                            <option value="4">Effect 3</option>
                            <option value="5">Effect 4</option>
                        </select>
                    </div>
                    -->
                    <div class="widget widget_price_filter">
                        <h3 class="widget-title">Filter by Price</h3>
                        <!-- price slider -->
                        <form method="get" action="<?php echo e(route('shop')); ?>" class="form-inline"  id="filterform">
                            <div class="slider-range-price"></div>
                            <input type="hidden" value="" name="min_price" />
                            <input type="hidden" value="" name="max_price" />
                            <div class="price_label" style=""> Price: <span class="price_from">2</span> - <span class="price_to">35</span> </div>
                            <div class="topmargin_20"> <button type="submit" class="theme_button color4 min_width_button">Filter</button> </div>
                        </form>
                    </div>

                    <div class="widget widget_shopping_cart">
                        <h3 class="widget-title">Your Cart</h3>
                        <div class="widget_shopping_cart_content">
                            <ul class="cart_list product_list_widget ">
                                <li class="media loop-color">
                                    <div class="media-left media-middle"> <a href="shop-product-right.html">
                                            <img src="/images/shop/01.jpg" class="muted_background" alt="">
                                        </a> </div>
                                    <div class="media-body media-middle"> <a href="#" class="remove" title="Remove this item"></a>
                                        <h4> <a href="shop-product-right.html">Drumstick short ribs</a> </h4> <span class="star-rating" title="Rated 5.0 out of 5">
								<span style="width:100%">
									<strong class="rating">5.0</strong> out of 5
								</span> </span> <span class="product-quantity">
								<span>1 x</span> <span class="price">$56.69</span> </span>
                                    </div>
                                </li>
                                <li class="media loop-color">
                                    <div class="media-left media-middle"> <a href="shop-product-right.html">
                                            <img src="/images/shop/02.jpg" class="muted_background" alt="">
                                        </a> </div>
                                    <div class="media-body media-middle"> <a href="#" class="remove" title="Remove this item"></a>
                                        <h4> <a href="shop-product-right.html">Drumstick short ribs</a> </h4> <span class="star-rating" title="Rated 5.0 out of 5">
								<span style="width:100%">
									<strong class="rating">5.0</strong> out of 5
								</span> </span> <span class="product-quantity">
								<span>1 x</span> <span class="price">$13.25</span> </span>
                                    </div>
                                </li>
                            </ul>
                            <p class="total"> <strong class="grey">Subtotal:</strong> <span class="price">$69.94</span> </p>
                            <p class="buttons"> <a href="shop-cart-right.html" class="theme_button color4 min_width_button">View cart</a> <a href="shop-cart-right.html" class="theme_button color4 inverse">Checkout</a> </p>
                        </div>
                    </div>
                </aside>
                <!-- eof aside sidebar -->
            </div>
        </div>
    </section>

    <style>
        /* Dropdown Button */
        .dropbtn {
            background-color: transparent;
            color: #a6a6a6;
            padding: 16px;
            font-style: italic;
            text-transform: uppercase;
            font-weight: 600;
            font-size: 12px;
            border: none;
            cursor: pointer;
        }

        /* Dropdown button on hover & focus */
        .dropbtn:hover, .dropbtn:focus {
            background-color: #3e8e41;
        }

        /* The search field */
        #myInput {
            border-box: box-sizing;
            background-image: url('searchicon.png');
            background-position: 14px 12px;
            background-repeat: no-repeat;
            font-size: 16px;
            padding: 14px 20px 12px 45px;
            border: none;
            border-bottom: 1px solid #ddd;
        }

        /* The search field when it gets focus/clicked on */
        #myInput:focus {outline: 3px solid #ddd;}

        /* The container <div> - needed to position the dropdown content */
        .dropdown {
            position: relative;
            display: inline-block;
        }

        /* Dropdown Content (Hidden by Default) */
        .dropdown-content {
            display: none;
            position: absolute;
            background-color: #f6f6f6;
            min-width: 230px;
            border: 1px solid #ddd;
            z-index: 2;
        }

        /* Links inside the dropdown */
        .dropdown-content a {
            color: black;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
            border: 1px solid rgba(128, 128, 128, 0.5);
            width: 100%&
        }

        /* Change color of dropdown links on hover */
        .dropdown-content a:hover {background-color: #f1f1f1}

        /* Show the dropdown menu (use JS to add this class to the .dropdown-content container when the user clicks on the dropdown button) */
        .show {display:block;}
    </style>
    <script>
        /* When the user clicks on the button,
toggle between hiding and showing the dropdown content */
        function myFunction() {
            document.getElementById("myDropdown").classList.toggle("show");
        }

        function filterFunction() {
            var input, filter, ul, li, a, i;
            input = document.getElementById("myInput");
            filter = input.value.toUpperCase();
            div = document.getElementById("myDropdown");
            a = div.getElementsByTagName("a");
            for (i = 0; i < a.length; i++) {
                if (a[i].innerHTML.toUpperCase().indexOf(filter) > -1) {
                    a[i].style.display = "";
                } else {
                    a[i].style.display = "none";
                }
            }
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>