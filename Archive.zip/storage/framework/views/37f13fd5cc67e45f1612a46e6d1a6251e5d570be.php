<section id="products" class="ds parallax page_shop section_padding_top_150 section_padding_bottom_150">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-sm-4"> <span class="small-text big highlight4">
					Il nostro Shop
				</span>
                <h2 class="section_header">Acquista qui i prodotti CBD</h2>
                <div class="widget widget_categories topmargin_50">
                    <ul class="greylinks color4">
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li> <a href="/shop/<?php echo e($category->slug); ?>"><?php echo e($category->name); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <p class="topmargin_40">
                    <a href="<?php echo e(route('shop')); ?>" class="theme_button color4">
                        Vai al negozio
                    </a>
                </p>
            </div>
            <div class="col-lg-9 col-sm-8">
                <div class="owl-carousel" data-nav="true" data-responsive-lg="3">
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <article class="product ls vertical-item content-padding rounded overflow_hidden loop-color">
                            <div class="item-media">
                                <img src="<?php echo e(asset($product->image)); ?>" alt="" />
                                <?php if(file_exists(public_path('/images/brands/'.$product->brand.'.png'))): ?>
                                    <img class="brand" src="/images/brands/<?php echo e($product->brand); ?>.png" style="width: 50px;">
                                <?php endif; ?>
                                <span class="price main_bg_color">
                                    <ins>
                                        <span class="amount">€ <?php echo e($product->getFormattedPriceAttribute()); ?></span>
                                    </ins>

                                </span>
                                <div class="product-buttons" style="z-index: 9999;">
                                    <a href="javascript:{}" onclick="document.getElementById('<?php echo e($product->id); ?>-favorite').submit();" class="favorite_button">
                                        <span class="sr-only">Add to favorite</span>
                                    </a>
                                    <a href="javascript:{}" onclick="document.getElementById('<?php echo e($product->id); ?>').submit();" class="add_to_cart">
                                        <span class="sr-only">Add to cart</span>
                                    </a>

                                    <form method="post" enctype="multipart/form-data" action="<?php echo e(route('cart.storeFavorite')); ?>" id="<?php echo e($product->id); ?>-favorite">
                                        <?php echo e(csrf_field()); ?>

                                        <input type="hidden" name="id" value="<?php echo e($product->id); ?>">
                                        <input type="hidden" name="name" value="<?php echo e($product->name); ?>">
                                        <input type="hidden" name="price" value="<?php echo e($product->getFormattedPriceAttribute()); ?>">
                                        <input type="hidden" name="product_quantity" value="1">
                                    </form>

                                    <form method="post" enctype="multipart/form-data" action="<?php echo e(route('cart.store')); ?>" id="<?php echo e($product->id); ?>">
                                        <?php echo e(csrf_field()); ?>

                                        <input type="hidden" name="id" value="<?php echo e($product->id); ?>">
                                        <input type="hidden" name="name" value="<?php echo e($product->name); ?>">
                                        <input type="hidden" name="price" value="<?php echo e($product->getFormattedPriceAttribute()); ?>">
                                        <input type="hidden" name="product_quantity" value="1">
                                    </form>
                                </div>
                            <div class="item-content">
                                <div class="cbd-level">
                                    <?php if($product->cbd > 0): ?>
                                        <h6>CBD <?php echo e($product->cbd); ?>%</h6>
                                        <div class="star-rating" title="Rated 5.0 out of 5">
                                                        <span style="width:<?php echo e($product->cbd * 5); ?>%">
                                                            <strong class="rating">5.0</strong> out of 5
                                                        </span>
                                        </div>
                                    <?php else: ?>
                                        <h6 style="color: #359a47"><?php echo e(strtoupper($categories->where('id', $product->category_id)->first()->name)); ?></h6>
                                    <?php endif; ?>

                                </div>
                                <h4 class="entry-title topmargin_5"> <a href="<?php echo e(route('shop.show', [$product->category->slug, $product->slug])); ?>"><?php echo e($product->name); ?></a> </h4>
                                <p class="content-3lines-ellipsis"><?php echo \Illuminate\Support\Str::words(strip_tags($product->flavour),$words = 12, $end='...'); ?></p>
                            </div>
                        </article>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</section>