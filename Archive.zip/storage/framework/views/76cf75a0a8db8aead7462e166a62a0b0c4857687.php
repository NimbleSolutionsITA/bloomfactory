<?php $__env->startSection('extra-css'); ?>
    <script src="https://js.stripe.com/v3/"></script>

    <style>
        /**
         * The CSS shown here will not be introduced in the Quickstart guide, but shows
         * how you can use CSS to style your Element's container.
         */
        .StripeElement {
            background-color: transparent;
            height: 50px;
            padding: 15px 20px 11px;
            border-radius: 10px;
            border: 1px solid rgba(128, 128, 128, 0.5);
            font-size: 16px;
            line-height: 30px;
            font-weight: 400;
        }

        .StripeElement--focus {
            box-shadow: 0 1px 3px 0 #cfd7df;
        }

        .StripeElement--invalid {
            border-color: #fa755a;
        }

        .StripeElement--webkit-autofill {
            background-color: #fefde5 !important;
        }
    </style>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('partials.breadcrumbs', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <section class="ls section_padding_top_100 section_padding_bottom_75 columns_padding_25">
        <div class="container">

            <?php if(session()->has('success_message')): ?>
                <div class="alert alert-success alert-dismissible">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                    <strong>Success!</strong> <?php echo e(session()->get('success_message')); ?>

                </div>
            <?php endif; ?>
            <?php if(count($errors) > 0): ?>
                <div class="alert alert-danger alert-dismissible">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <div class="row">
                <div class="col-sm-7 col-md-8 col-lg-8">
                    <div class="shop-info">Returning customer? <a data-toggle="collapse" href="#registeredForm" aria-expanded="false" aria-controls="registeredForm">Click here to login</a> </div>
                    <div class="collapse" id="registeredForm">
                        <form class="checkout with_border with_padding form-horizontal" role="form">
                            <p>If you have shopped with us before, please enter your details in the boxes below. If you are a new customer please proceed to the Billing &amp; Shipping section.</p>
                            <div class="form-group"> <label for="username" class="col-sm-3 control-label">
                                    <span class="grey">Nick or email:</span>
                                    <span class="required">*</span>
                                </label>
                                <div class="col-sm-9"> <input type="text" class="form-control" name="username" id="username"> </div>
                            </div>
                            <div class="form-group"> <label for="password" class="col-sm-3 control-label">
                                    <span class="grey">Password:</span>
                                    <span class="required">*</span>
                                </label>
                                <div class="col-sm-9"> <input class="form-control" type="password" name="password" id="password"> </div>
                            </div>
                            <div class="form-group">
                                <div class="col-sm-offset-3 col-sm-9">
                                    <div class="checkbox"> <label for="rememberme" class="control-label">
                                            <input name="rememberme" type="checkbox" id="rememberme" value="forever">
                                            Remember me
                                        </label> </div> <input type="submit" class="theme_button color1 topmargin_20" name="login" value="Login">
                                    <div class="lost_password"> <a href="#">Lost your password?</a> </div>
                                </div>
                            </div>
                        </form>
                    </div>
                    <h2>Billing Address</h2>
                    <form action="<?php echo e(route('checkout.store')); ?>" method="POST" class="form-horizontal checkout shop-checkout" role="form" id="payment-form" data-toggle="validator">
                        <?php echo e(csrf_field()); ?>

                        <div class="form-group"> <label for="billing_country" class="col-sm-3 control-label">
                                <span class="grey">Country:</span>
                                <span class="required">*</span>
                            </label>
                            <div class="col-sm-9">
                                <select class="form-control" name="billing_country" id="billing_country">
                                    <option value="">Select a country…</option>
                                    <option value="AX">Åland Islands</option>
                                    <option value="AF">Afghanistan</option>
                                    <option value="AL">Albania</option>
                                    <option value="GA">Gabon</option>
                                    <option value="GM">Gambia</option>
                                    <option value="GE">Georgia</option>
                                    <option value="DE">Germany</option>
                                    <option value="GH">Ghana</option>
                                    <option value="AE">United Arab Emirates</option>
                                    <option value="IT" selected="selected">Italy</option>
                                    <option value="ZW">Zimbabwe</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group validate-required" id="name_field"> <label for="name" class="col-sm-3 control-label">
                                <span class="grey">Name:</span>
                                <span class="required">*</span>
                            </label>
                            <div class="col-sm-9"> <input type="text" class="form-control " name="name" id="name" placeholder="" value="<?php echo e(old('name')); ?>" required> </div>
                        </div>
                        <!--
                        <div class="form-group" id="billing_company_field"> <label for="billing_company" class="col-sm-3 control-label">
                                <span class="grey">Company Name:</span>
                            </label>
                            <div class="col-sm-9"> <input type="text" class="form-control " name="billing_company" id="billing_company" placeholder="" value=""> </div>
                        </div>
                        -->
                        <div class="form-group address-field validate-required" id="address_field"> <label for="address" class="col-sm-3 control-label">
                                <span class="grey">Address:</span>
                                <span class="required">*</span>
                            </label>
                            <div class="col-sm-9"> <input type="text" class="form-control " name="address" id="address" placeholder="" value="<?php echo e(old('address')); ?>" required> </div>
                        </div>
                        <!--
                        <div class="form-group">
                            <div class="col-sm-offset-3 col-sm-9"> <input type="text" class="form-control " name="billing_address_2" id="billing_address_2" placeholder="" value=""> </div>
                        </div>
                        -->
                        <div class="form-group address-field validate-required" id="city_field"> <label for="city" class="col-sm-3 control-label">
                                <span class="grey">Town / City:</span>
                                <span class="required">*</span>
                            </label>
                            <div class="col-sm-9"> <input type="text" class="form-control " name="city" id="city" placeholder="" value="<?php echo e(old('city')); ?>" required> </div>
                        </div>
                        <div class="form-group address-field validate-state" id="province_field"> <label for="province" class="col-sm-3 control-label">
                                <span class="grey">Province:</span>
                            </label>
                            <div class="col-sm-9"> <input type="text" class="form-control " value="<?php echo e(old('province')); ?>" placeholder="" name="province" id="province" required> </div>
                        </div>
                        <div class="form-group address-field validate-required validate-postcode" id="postalcode_field"> <label for="postalcode" class="col-sm-3 control-label">
                                <span class="grey">Postcode:</span>
                                <span class="required">*</span>
                            </label>
                            <div class="col-sm-9"> <input type="number" class="form-control " name="postalcode" id="postalcode" placeholder="" value="<?php echo e(old('postalcode')); ?>" required> </div>
                        </div>
                        <div class="form-group validate-required validate-email" id="email_field"> <label for="email" class="col-sm-3 control-label">
                                <span class="grey">Email Address:</span>
                                <span class="required">*</span>
                            </label>
                            <div class="col-sm-9"> <input type="email" class="form-control " name="email" id="email" placeholder="" value="<?php echo e(old('email')); ?>" required> </div>
                        </div>
                        <div class="form-group validate-required validate-phone" id="phone_field"> <label for="phone" class="col-sm-3 control-label">
                                <span class="grey">Phone:</span>
                                <span class="required">*</span>
                            </label>
                            <div class="col-sm-9"> <input type="text" class="form-control " name="phone" id="phone" placeholder="" value="<?php echo e(old('phone')); ?>" required> </div>
                        </div>
                        <div class="form-group form-stripe">

                            <div class="form-group validate-required" id="name_on_card_field"> <label for="name_on_card" class="col-sm-3 control-label">
                                    <span class="grey">Name on card:</span>
                                    <span class="required">*</span>
                                </label>
                                <div class="col-sm-9"> <input type="text" class="form-control " name="name_on_card" id="name_on_card" placeholder="" value="<?php echo e(old('name_on_card')); ?>" required> </div>
                            </div>
                            <label for="card-element" class="col-sm-3 control-label" style="color: #333;">
                                Credit or debit card
                            </label>
                            <div class="col-sm-9">
                                <div id="card-element">
                                    <!-- A Stripe Element will be inserted here. -->
                                </div>
                            </div>

                            <!-- Used to display form errors. -->
                            <div id="card-errors" role="alert"></div>
                        </div>
                        <div class="form-group">
                            <div class="col-sm-offset-3 col-sm-9">
                                <div class="checkbox"> <label>
                                        <input type="checkbox"> Create an Account?
                                    </label> </div>
                                <div class="checkbox"> <label>
                                        <input type="checkbox"> Shop to Billing Address?
                                    </label> </div>
                            </div>
                        </div>
                        <!--
                        <div class="form-group">
                            <label for="order_comments" class="col-sm-3 control-label">
                                <span class="grey">Order Notes:</span>
                            </label>
                            <div class="col-sm-9"> <textarea name="order_comments" class="form-control" id="order_comments" placeholder="" rows="5"></textarea> </div>
                        </div>
                        -->
                    </form>
                </div>
                <!--eof .col-sm-8 (main content)-->
                <!-- sidebar -->
                <aside class="col-sm-5 col-md-4 col-lg-4">
                    <h3 class="widget-title" id="order_review_heading">Your order</h3>
                    <div id="order_review" class="shop-checkout-review-order">
                        <table class="table shop_table shop-checkout-review-order-table">
                            <thead>
                            <tr>
                                <td class="product-name">Product</td>
                                <td class="product-total">Total</td>
                            </tr>
                            </thead>
                            <tbody>
                            <tr class="cart_item">
                                <?php $__currentLoopData = Cart::content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <td class="product-name"> <?php echo e($item->model->name); ?> <span class="product-quantity">× <?php echo e($item->qty); ?></span> </td>
                                    <td class="product-total"> <span class="amount grey">$<?php echo e($item->model->price * $item->qty); ?></span> </td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                            </tbody>
                            <tfoot>
                            <tr class="cart-subtotal">
                                <td>Subtotal:</td>
                                <td> <span class="amount grey">$20.00</span> </td>
                            </tr>
                            <tr class="shipping">
                                <td>Shipping:</td>
                                <td> <span class="grey">Free Shipping</span> </td>
                            </tr>
                            <tr class="order-total">
                                <td>Total:</td>
                                <td> <span class="amount grey">
                                            <strong>$20.00</strong>
                                        </span> </td>
                            </tr>
                            </tfoot>
                        </table>
                        <div id="payment" class="shop-checkout-payment">
                            <h3 class="widget-title">Payment</h3>
                            <ul class="list1 no-bullets payment_methods methods">
                                <li class="payment_method_bacs">
                                    <div class="radio"> <label for="payment_method_bacs">
                                            <input id="payment_method_bacs" type="radio" name="payment_method" value="bacs" checked="checked">
                                            <span class="grey">Direct Bank Transfer</span>
                                        </label> </div>
                                    <div class="payment_box payment_method_bacs">
                                        <p>Make your payment directly into our bank account. Please use your Order ID as the payment reference. Your order won’t be shipped until the funds have cleared in our account.</p>
                                    </div>
                                </li>
                                <!--
                                <li class="payment_method_cheque">
                                    <div class="radio"> <label for="payment_method_cheque">
                                            <input id="payment_method_cheque" type="radio" name="payment_method" value="cheque">
                                            <span class="grey">Cheque Payment</span>
                                        </label> </div>
                                </li>
                                <li class="payment_method_paypal">
                                    <div class="radio"> <label for="payment_method_paypal">
                                            <input id="payment_method_paypal" type="radio" name="payment_method" value="paypal">
                                            <span class="grey">PayPal</span>

                                        </label> </div>
                                </li>
                                -->
                                <li class="payment_method_paypal">
                                    <div class="radio"> <label for="payment_method_stripe">
                                            <input id="payment_method_stripe" type="radio" name="payment_method" value="stripe">
                                            <span class="grey">Stripe</span>

                                        </label> </div>
                                </li>
                            </ul>

                            <div class="place-order">
                                <button class="theme_button color4" name="checkout_place_order" id="place_order" value="Place order"> Place Order </button>
                            </div>
                        </div>
                    </div>
                </aside>
                <!-- eof aside sidebar -->
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra-js'); ?>
    <script>
        $(document).ready(function() {

            $('.form-stripe').hide();

            $('input[type="radio"]').click(function() {
                if($(this).attr('id') == 'payment_method_stripe') {
                    $('.form-stripe').show();
                }

                else {
                    $('.form-stripe').hide();
                }
            });

            // Create a Stripe client.
            var stripe = Stripe('pk_test_HLaVb62hZOD8jU987wlb7GmR');

            // Create an instance of Elements.
            var elements = stripe.elements();

            // Custom styling can be passed to options when creating an Element.
            // (Note that this demo uses a wider set of styles than the guide below.)
            var style = {
                base: {
                    color: '#32325d',
                    lineHeight: '18px',
                    fontFamily: '"Raleway", sans-serif',
                    fontSmoothing: 'antialiased',
                    fontSize: '16px',
                    '::placeholder': {
                        color: '#aab7c4'
                    }
                },
                invalid: {
                    color: '#fa755a',
                    iconColor: '#fa755a'
                }
            };

            // Create an instance of the card Element.
            var card = elements.create('card', {
                style: style,
                hidePostalCode: true
            });

            // Add an instance of the card Element into the `card-element` <div>.
            card.mount('#card-element');

            // Handle real-time validation errors from the card Element.
            card.addEventListener('change', function (event) {
                var displayError = document.getElementById('card-errors');
                if (event.error) {
                    displayError.textContent = event.error.message;
                } else {
                    displayError.textContent = '';
                }
            });

            // Handle form submission.
            var form = document.getElementById('payment-form');

            $("#place_order").click( function(event) {
                event.preventDefault();

                // Disable submit button
                document.getElementById('place_order').disabled = true;

                var options = {
                    name: document.getElementById('name_on_card').value,
                    address_line1: document.getElementById('address').value,
                    address_city: document.getElementById('city').value,
                    address_state: document.getElementById('province').value,
                    address_zip: document.getElementById('postalcode').value
                };

                stripe.createToken(card, options).then(function (result) {
                    if (result.error) {
                        // Inform the user if there was an error.
                        var errorElement = document.getElementById('card-errors');
                        errorElement.textContent = result.error.message;

                        // Enable submit button
                        document.getElementById('place_order').disabled = false;

                    } else {
                        // Send the token to your server.
                        stripeTokenHandler(result.token);
                    }
                });
            });

            function stripeTokenHandler(token) {
                // Insert the token ID into the form so it gets submitted to the server
                var form = document.getElementById('payment-form');
                var hiddenInput = document.createElement('input');
                hiddenInput.setAttribute('type', 'hidden');
                hiddenInput.setAttribute('name', 'stripeToken');
                hiddenInput.setAttribute('value', token.id);
                form.appendChild(hiddenInput);

                // Submit the form
                form.submit();
            }
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>