<?php $__env->startSection('title', $title); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('partials.breadcrumbs', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <section class="ls section_padding_top_150 section_padding_bottom_100 columns_padding_30">
        <div class="container">
            <div class="row">
                <div class="col-sm-7 col-md-8 col-lg-8 col-sm-push-5 col-md-push-4 col-lg-push-4">
                    <div class="shop-sorting">
                        <form class="form-inline content-justify vertical-center content-margins">
                            <?php if($products->total() == 0): ?>
                                <div>Nessun risultato</div>
                            <?php else: ?>
                                <div> Showing <?php echo e((($products->currentPage() - 1) * $products->perPage()) + 1); ?>-
                                    <?php if($products->currentPage() == $products->lastPage()): ?>
                                        <?php echo e($products->total()); ?>

                                    <?php else: ?>
                                        <?php echo e($products->currentPage() * 4); ?>

                                    <?php endif; ?>
                                    of <?php echo e($products->total()); ?> results
                                </div>
                            <?php endif; ?>
                            <div class="form-group select-group">
                                <select aria-required="true" id="sort" name="sort" class="choice empty form-control" onchange="this.form.submit()">
                                    <option value="" disabled selected data-default>Ordinamento predefinito</option>
                                    <option <?php echo e(request('sort') == 'pra' ? 'selected' : ''); ?> value="pra">per Prezzo asc</option>
                                    <option <?php echo e(request('sort') == 'prd' ? 'selected' : ''); ?> value="prd">per Prezzo dsc</option>
                                    <option <?php echo e(request('sort') == 'naa' ? 'selected' : ''); ?> value="naa">per Nome asc</option>
                                    <option <?php echo e(request('sort') == 'nad' ? 'selected' : ''); ?> value="nad">per Nome dsc</option>
                                </select>
                                <i class="fa fa-angle-down theme_button color1 no_bg_button" aria-hidden="true"></i>
                            </div>
                        </form>
                    </div>
                    <div class="columns-2">
                        <ul id="products" class="products list-unstyled">

                            <?php $__currentLoopData = $products->getCollection()->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <li class="product type-product loop-color">
                                    <article class="vertical-item content-padding rounded overflow_hidden with_background">
                                        <div class="item-media">
                                            <img src="<?php echo e(asset($product->image)); ?>" alt="" />
                                            <?php if(file_exists(public_path('/images/brands/'.$product->brand.'.png'))): ?>
                                                <img class="brand" src="/images/brands/<?php echo e($product->brand); ?>.png">
                                            <?php endif; ?>
                                            <span class="price main_bg_color">
                                                <ins>€ <span class="amount"><?php echo e($product->getFormattedPriceAttribute()); ?></span></ins>
                                            </span>
                                            <div class="product-buttons">
                                                <a href="javascript:{}" onclick="document.getElementById('<?php echo e($product->id); ?>-favorite').submit();" class="favorite_button">
                                                    <span class="sr-only">Add to favorite</span>
                                                </a>
                                                <a href="javascript:{}" onclick="document.getElementById('<?php echo e($product->id); ?>').submit();" class="add_to_cart">
                                                    <span class="sr-only">Add to cart</span>
                                                </a>

                                                <form method="post" enctype="multipart/form-data" action="<?php echo e(route('cart.storeFavorite')); ?>" id="<?php echo e($product->id); ?>-favorite">
                                                    <?php echo e(csrf_field()); ?>

                                                    <input type="hidden" name="id" value="<?php echo e($product->id); ?>">
                                                    <input type="hidden" name="name" value="<?php echo e($product->name); ?>">
                                                    <input type="hidden" name="price" value="<?php echo e($product->getFormattedPriceAttribute()); ?>">
                                                    <input type="hidden" name="product_quantity" value="1">
                                                </form>

                                                <form method="post" enctype="multipart/form-data" action="<?php echo e(route('cart.store')); ?>" id="<?php echo e($product->id); ?>">
                                                    <?php echo e(csrf_field()); ?>

                                                    <input type="hidden" name="id" value="<?php echo e($product->id); ?>">
                                                    <input type="hidden" name="name" value="<?php echo e($product->name); ?>">
                                                    <input type="hidden" name="price" value="<?php echo e($product->getFormattedPriceAttribute()); ?>">
                                                    <input type="hidden" name="product_quantity" value="1">
                                                </form>
                                            </div>
                                        </div>
                                        <div class="item-content">
                                            <div class="cbd-level">
                                                <?php if($product->cbd > 0): ?>
                                                    <h6>CBD <?php echo e($product->cbd); ?>%</h6>
                                                    <div class="star-rating" title="Rated 5.0 out of 5">
                                                        <span style="width:<?php echo e($product->cbd * 5); ?>%">
                                                            <strong class="rating">5.0</strong> out of 5
                                                        </span>
                                                    </div>
                                                <?php else: ?>
                                                    <h6 style="color: #359a47"><?php echo e(strtoupper($categories->where('id', $product->category_id)->first()->name)); ?></h6>
                                                <?php endif; ?>

                                            </div>
                                            <h4 class="entry-title topmargin_5"><span><?php echo e($product->brand); ?></span> <a href="<?php echo e(route('shop.show', [$product->category->slug, $product->slug])); ?>"><?php echo e($product->name); ?></a> </h4>
                                            <p class="content-3lines-ellipsis"><?php echo \Illuminate\Support\Str::words(strip_tags($product->flavour),$words = 15, $end='...'); ?></p>
                                        </div>
                                    </article>
                                </li>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        </ul>
                    </div>
                    <!-- eof .columns-* -->
                    <div class="row">
                        <div class="col-sm-12 text-center">
                            <?php echo e($products->links()); ?>

                        </div>
                    </div>
                </div>
                <aside class="col-sm-5 col-md-4 col-lg-4 col-sm-pull-7 col-md-pull-8 col-lg-pull-8">

                    <div class="widget widget_search">
                        <h3 class="widget-title">Cerca ora</h3>
                        <form method="get" class="form-inline" action="<?php echo e(route('shop')); ?>">
                            <div class="form-group margin_0">
                                <label class="sr-only" for="widget-search">Search for:</label>
                                <input id="widget-search" type="text" value="" name="keyword" class="form-control" placeholder="Inserisci le prole chiave...">
                            </div>
                            <button type="submit" class="theme_button color1 no_bg_button">Search</button>
                        </form>
                    </div>
                    <div class="widget widget_categories">
                        <h3 class="widget-title">Tutte le categorie</h3>
                        <select name="cat" class="wrap-select-group" form="filterform">
                            <option value="0">Tutte</option>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option <?php echo e(request('cat') == $category->id ? 'selected' : ''); ?> value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <!--
                    <div class="widget widget_categories">
                        <h3 class="widget-title">Flavor / Smell</h3> <select name="cat" class="wrap-select-group">
                            <option value="1">All</option>
                            <option value="2">Type 1</option>
                            <option value="3">Type 2</option>
                            <option value="4">Type 3</option>
                            <option value="5">Type 4</option>
                        </select>
                    </div>
                    <div class="widget widget_categories">
                        <h3 class="widget-title">Effect</h3> <select name="cat" class="wrap-select-group">
                            <option value="1">All</option>
                            <option value="2">Effect 1</option>
                            <option value="3">Effect 2</option>
                            <option value="4">Effect 3</option>
                            <option value="5">Effect 4</option>
                        </select>
                    </div>
                    -->
                    <div class="widget widget_price_filter">
                        <h3 class="widget-title">Filtra per prezzo</h3>
                        <!-- price slider -->
                        <form method="get" action="<?php echo e(route('shop')); ?>" class="form-inline"  id="filterform">
                            <div class="slider-range-price"></div>
                            <input type="hidden" value="" name="min_price" />
                            <input type="hidden" value="" name="max_price" />
                            <div class="price_label" style=""> Prezzo: <span class="price_from">2</span> - <span class="price_to">35</span> </div>
                            <div class="topmargin_20"> <button type="submit" class="theme_button color1 min_width_button">Filtra</button> </div>
                        </form>
                    </div>

                    <div class="widget widget_shopping_cart">
                        <h3 class="widget-title">Il tuo carrello</h3>
                        <div class="widget_shopping_cart_content">
                            <ul class="cart_list product_list_widget ">
                                <?php $__currentLoopData = Cart::content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="media loop-color">
                                        <div class="media-left media-middle"> <a href="shop-product-right.html">
                                                <img src="<?php echo e(asset($item->model->image)); ?>" class="muted_background" alt="">
                                            </a> </div>
                                        <div class="media-body media-middle">
                                            <form action="<?php echo e(route('cart.destroy', $item->rowId)); ?>" method="POST" id="<?php echo e($item->rowId); ?>">
                                                <?php echo e(csrf_field()); ?>

                                                <?php echo e(method_field('DELETE')); ?>

                                                <a href="javascript:{}" onclick="document.getElementById('<?php echo e($item->rowId); ?>').submit();" class="remove" title="Remove this item"></a>
                                            </form>
                                            <h4> <a href=""><?php echo e($item->model->name); ?></a> </h4>
                                            <span class="cart-brand" style="color: #369a47"><?php echo e($item->model->brand); ?></span>
                                            <span class="product-quantity">
                                                <span><?php echo e($item->qty); ?> x</span>
                                                <span class="price">€<?php echo e($item->model->getFormattedPriceAttribute()); ?></span>
                                            </span>
                                        </div>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                            <p class="total"> <strong class="grey">Totale prodotti:</strong> <span class="price">€ <?php echo e(number_format(Cart::subtotal(), 2)); ?></span> </p>
                            <p class="buttons">
                                <a href="<?php echo e(route('cart.index')); ?>" class="theme_button color1 min_width_button">Vedi Carrello</a>
                                <a href="<?php echo e(route('checkout.index')); ?>" class="theme_button color1 inverse">Checkout</a>
                            </p>
                        </div>
                    </div>
                </aside>
                <!-- eof aside sidebar -->
            </div>
        </div>
    </section>

    <style>
        /* Dropdown Button */
        .dropbtn {
            background-color: transparent;
            color: #a6a6a6;
            padding: 16px;
            font-style: italic;
            text-transform: uppercase;
            font-weight: 600;
            font-size: 12px;
            border: none;
            cursor: pointer;
        }

        /* Dropdown button on hover & focus */
        .dropbtn:hover, .dropbtn:focus {
            background-color: #3e8e41;
        }

        /* The search field */
        #myInput {
            border-box: box-sizing;
            background-image: url('searchicon.png');
            background-position: 14px 12px;
            background-repeat: no-repeat;
            font-size: 16px;
            padding: 14px 20px 12px 45px;
            border: none;
            border-bottom: 1px solid #ddd;
        }

        /* The search field when it gets focus/clicked on */
        #myInput:focus {outline: 3px solid #ddd;}

        /* The container <div> - needed to position the dropdown content */
        .dropdown {
            position: relative;
            display: inline-block;
        }

        /* Dropdown Content (Hidden by Default) */
        .dropdown-content {
            display: none;
            position: absolute;
            background-color: #f6f6f6;
            min-width: 230px;
            border: 1px solid #ddd;
            z-index: 2;
        }

        /* Links inside the dropdown */
        .dropdown-content a {
            color: black;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
            border: 1px solid rgba(128, 128, 128, 0.5);
            width: 100%&
        }

        /* Change color of dropdown links on hover */
        .dropdown-content a:hover {background-color: #f1f1f1}

        /* Show the dropdown menu (use JS to add this class to the .dropdown-content container when the user clicks on the dropdown button) */
        .show {display:block;}
    </style>
    <script>
        /* When the user clicks on the button,
toggle between hiding and showing the dropdown content */
        function myFunction() {
            document.getElementById("myDropdown").classList.toggle("show");
        }

        function filterFunction() {
            var input, filter, ul, li, a, i;
            input = document.getElementById("myInput");
            filter = input.value.toUpperCase();
            div = document.getElementById("myDropdown");
            a = div.getElementsByTagName("a");
            for (i = 0; i < a.length; i++) {
                if (a[i].innerHTML.toUpperCase().indexOf(filter) > -1) {
                    a[i].style.display = "";
                } else {
                    a[i].style.display = "none";
                }
            }
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>