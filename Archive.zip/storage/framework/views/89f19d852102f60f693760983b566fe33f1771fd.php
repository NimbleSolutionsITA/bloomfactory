<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('partials.breadcrumbs', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <section class="ls section_padding_top_100 section_padding_bottom_75 columns_padding_25">
        <div class="container">

            <?php if(session()->has('success_message')): ?>
                <div class="alert alert-success alert-dismissible">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                    <strong>Success!</strong> <?php echo e(session()->get('success_message')); ?>

                </div>
            <?php endif; ?>
            <?php if(count($errors) > 0): ?>
                <div class="alert alert-danger alert-dismissible">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <div class="row">
                <!-- <div class="col-sm-7 col-md-8 col-lg-8 col-sm-push-5 col-md-push-4 col-lg-push-4"> -->
                 <div class="col-sm-12">
                    <div class="table-responsive">
                        <table class="table shop_table cart cart-table">
                            <thead>
                            <tr>
                                <td class="product-info">Product</td>
                                <td class="product-price-td">Price</td>
                                <td class="product-quantity">Quantity</td>
                                <td class="product-subtotal">Subtotal</td>
                                <td class="product-remove">&nbsp;</td>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = Cart::content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <tr class="cart_item">
                                    <td class="product-info">
                                        <div class="media">
                                            <div class="media-left"> <a href="shop-product-right.html">
                                                    <img class="media-object cart-product-image" src="/images/shop/01.jpg" alt="">
                                                </a>
                                            </div>
                                            <div class="media-body">
                                                <h4 class="media-heading"> <a href="<?php echo e(route('shop.show', $item->model->slug)); ?>"><?php echo e($item->model->name); ?></a> </h4>
                                                <span class="grey">Color:</span> Black<br>
                                                <span class="grey">Size:</span> M
                                             </div>
                                        </div>
                                    </td>
                                    <td class="product-price"> <span class="currencies">$</span><span class="amount"><?php echo e($item->model->price); ?></span> </td>
                                    <td class="product-quantity">
                                        <form action="<?php echo e(route('cart.update', $item->rowId)); ?>" method="POST">
                                            <?php echo e(csrf_field()); ?>

                                            <select class="quantity" data-id='<?php echo e($item->rowId); ?>'>
                                                <?php for($i = 1; $i < 10 + 1 ; $i++): ?>
                                                    <option <?php echo e($item->qty == $i ? 'selected' : ''); ?>><?php echo e($i); ?></option>
                                                <?php endfor; ?>
                                            </select>
                                        </form>
                                    </td>
                                    <td class="product-subtotal"> <span class="currencies">$</span><span class="amount"><?php echo e($item->model->price * $item->qty); ?></span> </td>
                                    <td class="product-remove">
                                        <form action="<?php echo e(route('cart.destroy', $item->rowId)); ?>" method="POST">
                                            <?php echo e(csrf_field()); ?>

                                            <?php echo e(method_field('DELETE')); ?>

                                            <button type="submit" class="remove fontsize_20" title="Remove this item">
                                                <i class="fa fa-trash-o"></i>
                                            </button>
                                        </form>
                                    </td>
                                </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="cart-buttons">
                        <a class="theme_button color1" href="<?php echo e(route('shop')); ?>">Continue Shopping</a>
                        <a href="<?php echo e(route('checkout.index')); ?>" class="theme_button inverse">Proceed to Checkout</a>
                    </div>
                    <div class="cart-collaterals">
                        <div class="cart_totals">
                            <h4>Cart Totals</h4>
                            <table class="table">
                                <tbody>
                                <tr class="cart-subtotal">
                                    <td>Cart Subtotal</td>
                                    <td><span class="currencies">$</span><span class="amount"><?php echo e(Cart::subtotal()); ?></span> </td>
                                </tr>
                                <tr class="shipping">
                                    <td>Shipping and Handling</td>
                                    <?php if(Cart::subtotal()>50 || Cart::count()==0): ?>
                                        <td> Free Shipping </td>
                                    <?php else: ?>
                                        <td> $5 </td>
                                    <?php endif; ?>
                                </tr>
                                <tr class="order-total">
                                    <td class="grey">Order Total</td>
                                    <td><strong class="grey"><span class="currencies">$</span><span class="amount">
                                    <?php if(Cart::subtotal()>50): ?>
                                            <?php echo e(Cart::total()); ?>

                                        <?php else: ?>
                                            <?php echo e(Cart::total() + 5); ?>

                                        <?php endif; ?>
                                    </span> </strong> </td>
                                </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="coupon with_padding rounded with_background">
                                <h4 class="topmargin_0">Discount Codes</h4>
                                <p>Enter coupon code if you have one</p>
                                <div class="form-group"> <label class="sr-only" for="coupon_code">Coupon:</label> <input type="text" name="coupon_code" class="form-control" id="coupon_code" value="" placeholder="Coupon code"> </div> <a class="theme_button color4" href="#">Apply Coupon</a> </div>
                        </div>
                        <div class="col-md-6">
                            <div class="shipping-calculator-form with_padding rounded with_background">
                                <h4 class="topmargin_0">Shipping &amp; Tax</h4>
                                <p>Enter destination to get shipping</p>
                                <div class="form-group"> <select name="calc_shipping_country" id="calc_shipping_country" class="country_to_state form-control">
                                        <option value="">Select a country…</option>
                                        <option value="AX">Åland Islands</option>
                                        <option value="OM">Oman</option>
                                        <option value="GB" selected="selected">United Kingdom (UK)</option>

                                    </select> </div>
                                <div class="form-group"> <input type="text" class="form-control" value="" placeholder="State / county" name="calc_shipping_state" id="calc_shipping_state"> </div>
                                <div class="form-group"> <input type="text" class="form-control" value="" placeholder="Postcode / Zip" name="calc_shipping_postcode" id="calc_shipping_postcode"> </div>
                                <div> <button type="submit" name="calc_shipping" class="theme_button color4" value="1">Update Totals</button> </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!--eof .col-sm-8 (main content)-->
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra-js'); ?>
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    <script>
        (function() {
            const classname = document.querySelectorAll('.quantity');

            Array.from(classname).forEach(function(element) {
                element.addEventListener('change', function () {
                    const id = element.getAttribute('data-id');
                    axios.patch(`/cart/${id}`, {
                        quantity: this.value
                    })
                        .then(function (response) {
                            window.location.href = '<?php echo e(route('cart.index')); ?>'
                        })
                        .catch(function (error) {
                            console.log(error);
                            window.location.href = '<?php echo e(route('cart.index')); ?>'
                        });
                });
            })
        })();
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>