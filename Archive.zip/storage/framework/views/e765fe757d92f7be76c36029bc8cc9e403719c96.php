<ul class="mainmenu nav sf-menu">
    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><a href="<?php echo e($menu_item->link()); ?>"><?php echo e($menu_item->title); ?><?php if($menu_item->children->count()): ?><b class="caret"></b><?php endif; ?></a>

                <?php if($menu_item->children->count()): ?>
                        <ul class="submenu">
                                <?php $__currentLoopData = $menu_item->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><a href="<?php echo e($item->url); ?>"><?php echo e($item->title); ?> </a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>

                <?php endif; ?>
        </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>