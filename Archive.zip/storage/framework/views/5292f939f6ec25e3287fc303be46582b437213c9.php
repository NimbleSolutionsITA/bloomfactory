<section class="page_breadcrumbs ds parallax section_padding_top_40 section_padding_bottom_40">
    <div class="container">
        <div class="row">
            <div class="col-sm-12 text-center">
                <h2><?php echo $__env->yieldContent('title'); ?></h2>
                <ol class="breadcrumb greylinks color1">
                    <li><a href="/">Home</a></li>
                    <li><i class="fa fa-chevron-circle-right"></i></li>
                    <?php for($i = 1; $i <= count(Request::segments()); $i++): ?>
                        <?php if($i == count(Request::segments())): ?>
                            <?php if(Request::segment($i) == 'shop' && isset($_GET['cat'])): ?>
                                <li><a href="/<?php echo e(Request::segment($i)); ?>"><?php echo e(Request::segment($i)); ?></a></li>
                            <?php endif; ?>
                            <li class="active"><?php echo $__env->yieldContent('title'); ?></li>
                        <?php elseif(Request::segment($i-1) == 'shop'): ?>
                            <li><a href="/shop/<?php echo e(Request::segment($i)); ?>"><?php echo e(Request::segment($i)); ?></a></li>
                            <li><i class="fa fa-chevron-circle-right"></i></li>
                        <?php elseif(Request::segment($i) == 'password'): ?>
                        <?php else: ?>
                            <li><a href="/<?php echo e(Request::segment($i)); ?>"><?php echo e(Request::segment($i)); ?></a></li>
                            <li><i class="fa fa-chevron-circle-right"></i></li>
                        <?php endif; ?>
                    <?php endfor; ?>
                </ol>
            </div>
        </div>
    </div>
</section>