@extends('layouts.app')

@section('content')

    @include('partials.home_slider')

    @include('partials.home_macro_categories')

    @include('partials.home_benefici')

    @include('partials.product_preview')

    @include('partials.newsletter')

@endsection
