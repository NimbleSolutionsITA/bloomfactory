@extends('layouts.app')

@section('title', 'Chi Siamo')

@section('content')

    @include('partials.breadcrumbs')

@endsection
