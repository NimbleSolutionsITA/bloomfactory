@extends('layouts.app')

@section('title', 'Cookie Policy')

@section('content')

    @include('partials.breadcrumbs')

@endsection
